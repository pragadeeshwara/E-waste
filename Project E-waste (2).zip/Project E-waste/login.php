<?php
     echo "this is for test";
     $email = $_POST['email'];
     $password = $_POST['password'];
     echo $email;

     $con = new mysqli("localhost","root","ewastedb","test");
     if($con->connect_error)  
     {
        die("Failed to connect :".$con->connect_error);
     }
     else{
        $stmt = $con->prepare("select * from registration where email = ?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $stmt_result = $stmt->get_result();
        if($stmt_result->num_rows > 0){
             $data = $stmt_result->fetch_assoc();
             if($data['password'] === $password){
                echo "Login Success";
             }
             else{
                echo "Invalid email or password";
             }
        }else{
            echo "<h2> Invalid Email or Password</h2>";

        }
     }
?>
