import csv

def searchByCategory():
    Category=input("Enter ur Category :")
    csv_file=csv.reader(open('F:\Project E-waste\projectdataset.csv','r'))
     

    for row in csv_file:
       if Category==row[1]:
         print(row)


def searchByProcessor():
   processor=str(input("Enter Your Processor :"))
   csv_file=csv.reader(open('F:\Project E-waste\projectdataset.csv','r'))
   for i in csv_file:
      if processor==csv_file[i]:
         print(i)


print("Enter 1 to Search By Category")
print("Enter 2 to search By Processor")

src=int(input("Enter here:"))

if src==1 :
   searchByCategory()
elif src==2 :
   searchByProcessor()
else :
   print("Sorry Invalid Input")      
