print("Welcometo credit Area")
import csv

data=[]
with open("F:\Project E-waste\Project E-waste\projectdataset.csv") as csvfile:
    reader=csv.reader(csvfile)
    for row in reader:
        data.append(row)
        #print(data)
#print(data)

name=input("Enter ur Category :")

col = [x[0] for x in data]
#print(col)
if name in col:
    for x in range(0,len(data)):
        if name==data[x][0]:
            print(data[x])
else :
    print("Name Doesn't Exist")            
            
    